# テスト計画

> English: [TEST_PLAN.md](TEST_PLAN.md)

## テスト方針

テストはソフトウェアで環境を完全に制御できるかどうかに基づいて2種類に分けます。

**自動テスト**はCIまたはローカルで人の操作なしに実行します。
入力はすべてプログラムで生成し、期待される出力はすべてアサーションで検証します。

**手動テスト**は環境をソフトウェアで完全に制御できない場合に使います。
「自動化が面倒だから」ではなく、エミュレートできない物理ハードウェアが必須である、または人の判断（目視確認・触覚フィードバックなど）による検証が本質的に必要である場合に限ります。

```
tests/
  peer/       自動 — ESP32-S3 2台構成（1台ホスト + 1台デバイス）
  loopback/   自動 — ESP32-P4 1台でホストとデバイスを同時実行（整備中）
  manual/     手動 — 特殊ハードウェアまたは人による操作が必要
```

ハードウェアの接続方法や個別テストの詳細は、各サブディレクトリの README を参照してください。

---

## テストカバレッジ一覧

| 機能 | 自動 | 手動 | 未カバー |
|------|------|------|---------|
| HIDキーボード入力 | ✅ peer | | |
| HIDキーボードレイアウト（JP） | | | ⬜ |
| HIDマウス入力 | ✅ peer | | |
| HIDコンシューマーコントロール | ✅ peer | | |
| HIDシステムコントロール | ✅ peer | | |
| HIDゲームパッド | ✅ peer | | |
| HIDベンダー入出力 | ✅ peer | | |
| HID生データダンプ | ✅ peer (custom_hid) | | |
| キーボードLED出力 | ✅ peer (hid_logic) | ✅ manual（目視） | |
| USBシリアル — CDC ACM | ✅ peer、line coding設定 | | |
| USBシリアル — VCP（FTDI・CP210x・CH34x） | | ✅ manual、シリアル形式設定 | |
| USB MIDI | ✅ peer | | |
| USBオーディオ入出力 | ✅ peer（出力）、入力は一部 | | |
| USB Mass Storage — ブロックI/O / FatFsマウント | ✅ peer（容量、Inquiry/Sense、read/write、範囲外拒否、write失敗検出） | ✅ manual（実USBメモリの容量取得、LBA0 read、FatFs/VFS mount、`fs::FS` wrapper、ファイルwrite/read/delete、mount中disconnect/remount） | ⬜ data phase失敗後の完全なBOT復旧、複数LUN、32-bit sector超のFatFs mount |
| 複数デバイス同時接続 | | ✅ manual | |
| デバイス活線挿抜 | | ✅ manual | |
| HUB検出・トポロジー・ポート電源制御 | | ✅ manual（`hub_info`、`hub_power`） | ⬜ change bit clear、複数段Hub、USB 3.x Hub互換性 |
