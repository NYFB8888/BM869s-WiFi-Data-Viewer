# Test Plan

> 日本語版: [TEST_PLAN.ja.md](TEST_PLAN.ja.md)

## Testing strategy

Tests are divided into two categories based on whether the test environment can be fully controlled by software.

**Automated tests** run in CI or locally without human interaction.
All inputs are generated programmatically; all expected outputs are verified by assertion.

**Manual tests** are used when the environment cannot be fully controlled by software — not because automation is inconvenient, but because the test inherently requires physical hardware that cannot be emulated, or verification that requires human judgment (visual inspection, tactile feedback, etc.).

```
tests/
  peer/       Automated — two ESP32-S3 boards, one host + one device
  loopback/   Automated — single ESP32-P4 running both host and device (WIP)
  manual/     Manual — special hardware or human interaction required
```

See each subdirectory's README for hardware setup and individual test details.

---

## Test coverage matrix

| Feature | Automated | Manual | Not covered |
|---------|-----------|--------|-------------|
| HID keyboard input | ✅ peer | | |
| HID keyboard layout (JP) | | | ⬜ |
| HID mouse input | ✅ peer | | |
| HID consumer control | ✅ peer | | |
| HID system control | ✅ peer | | |
| HID gamepad | ✅ peer | | |
| HID vendor input/output | ✅ peer | | |
| HID raw input dump | ✅ peer (custom_hid) | | |
| Keyboard LED output | ✅ peer (hid_logic) | ✅ manual (visual) | |
| USB serial — CDC ACM | ✅ peer, line coding config | | |
| USB serial — VCP (FTDI/CP210x/CH34x) | | ✅ manual, serial format configs | |
| USB MIDI | ✅ peer | | |
| USB audio input/output | ✅ peer (output), partial input | | |
| USB Mass Storage — block I/O / FatFs mount | ✅ peer (capacity, Inquiry/Sense, read/write, out-of-range rejection, write failure reporting) | ✅ manual (real USB flash capacity, LBA0 read, FatFs/VFS mount, `fs::FS` wrapper, file write/read/delete, mounted disconnect/remount) | ⬜ full BOT recovery after failed data phase, multiple LUNs, >32-bit-sector FatFs mount |
| Multiple devices | | ✅ manual | |
| Device hot-plug | | ✅ manual | |
| HUB detection, topology, and port power control | | ✅ manual (`hub_info`, `hub_power`) | ⬜ change bit clear, cascaded hubs, USB 3.x hub compatibility |
