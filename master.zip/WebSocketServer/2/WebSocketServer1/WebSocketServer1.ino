/**
 * WebSocketServer.ino
 * ===================
 * WiFi + WebSocket gateway for BU-86X DMM readings.
 * Shows large digits in a browser — ideal for vision-impaired use.
 *
 * WHAT IT DOES
 * ------------
 *  - Connects to your WiFi
 *  - Starts a web server on port 80
 *  - Pushes live DMM readings via WebSocket every 500ms
 *  - Browser page shows large digits auto-updating without reload
 *  - Also serves a REST endpoint: GET /reading  (returns JSON)
 *
 * DEPENDENCIES
 * ------------
 *  - BU86X library (this library)
 *  - ESPAsyncWebServer  (install via Library Manager)
 *  - AsyncTCP           (install via Library Manager)
 *
 * BOARD SETTINGS
 *  USB Mode:    USB-OTG (TinyUSB)
 *  Upload Mode: USB-OTG (TinyUSB)
 *
 * WIRING
 *  BOTTOM USB (OTG) --> BU-86X --> DMM (ON)
 *  TOP USB (CH343)  --> PC for flashing / Serial Monitor
 */

#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include <BU86X.h>

// ── WiFi credentials — edit these ────────────────────────────────
const char* WIFI_SSID = "LMG";
const char* WIFI_PASS = "lucek123";

// ── Objects ───────────────────────────────────────────────────────
BU86X            dmm;
AsyncWebServer   server(80);
AsyncWebSocket   ws("/ws");

// ── Latest reading (shared between DMM task and web callbacks) ────
volatile bool     newReading = false;
BU86X_Reading     latest;
portMUX_TYPE      mux = portMUX_INITIALIZER_UNLOCKED;

// ─────────────────────────────────────────────────────────────────
//  HTML page — served once, then WebSocket pushes updates
// ─────────────────────────────────────────────────────────────────
static const char INDEX_HTML[] PROGMEM = R"rawhtml(


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DMM Display</title>
<style>
  html,body{
      height: 100vh;
      margin: 0;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background: #0a0a0a;
    color: #00ff88;
    font-family: 'Courier New', monospace;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    padding: 20px;
  }

  h1 { font-size: 3em; color: orange;  margin: .67em 0 }

  #status {
    font-size: 1rem;
    color: #555;
    margin-bottom: 30px;
  }
  #status.ok  { color: #00ff88; }
  #status.err { color: #ff4444; }
  .display-box {
    background: #111;
    border: 2px solid #333;
    border-radius: 12px;
    padding: 30px 40px;
    margin: 10px;
    text-align: center;
    min-width: 320px;
  }
  .label {
    font-size: 0.9rem;
    color: #555;
    text-transform: uppercase;
    letter-spacing: 3px;
    margin-bottom: 10px;
  }
  .value {
    font-size: 5rem;
    font-weight: bold;
    letter-spacing: 4px;
    line-height: 1;
    color: #00ff88;
    text-shadow: 0 0 20px rgba(0,255,136,0.5);
  }
  .unit {
    font-size: 2rem;
    font-weight: bolder;
    color: #00ff88;
    margin-top: 8px;
    letter-spacing: 2px;
  }
  .sub .value  { 
    font-size: 2rem; 
    color: #0088ff; 
    text-shadow: 0 0 15px rgba(0,136,255,0.4);
   }
  .sub .unit   { 
    font-size: 1.2rem;
    color: #0088ff;
   }

  .flags {
    font-size: 0.8rem;
    color: #444;
    margin-top: 20px;
    letter-spacing: 2px;
  }

  .flags span.on { color: #ffaa00; }

  table {
    border: 0px;
    border-collapse: collapse;
  }

  td {
    border: 0px;
    padding: 10px;
  }

  .table_display{
    width: 90%;
    height: 50%;
  }
  
  .td_main{
    width: 60%;
    height: 60%;
    background: gray;
    border-radius: 10px;   /* round corners */
    overflow: hidden; 
  }

  .td_sub{
    background: gray;
      border-radius: 10px;   /* round corners */
    overflow: hidden; 
  }

</style>
</head>
<body>
  <h1>DMM 869s </h1>
  <div id="status">Connecting...</div>

  <table class="table_display">
    <tr>
      <td></td>
      <td class="td_sub">
        <table width=100%>
          <tr>
            <td width="70%" align="right">
              <div class="value" id="subValue">----</div>
            </td>
            <td align="left">
              <div class="unit"  id="subUnit">--</div>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td class="td_main"> <div class="flags" id="flags"></div>
        <table width="100%" >
          <tr>
            <td width="70%" align="right" >
              <div class="value" id="mainValue">-----</div>
            </td>
            <td align="left">
              <div class="unit"  id="mainUnit">---</div>
            </td>
          </tr>
        </table>
      </td>
      <td></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><div class="flags" id="flags"></div></div></td>
    </tr>
  </table>

  <!--div class="flags" id="flags"></div-->

<script>
  const $ = id => document.getElementById(id);
  let ws, retryTimer;

  function connect() {
    ws = new WebSocket('ws://' + location.host + '/ws');

    ws.onopen = () => {
      $('status').textContent = 'Connected';
      $('status').className = 'ok';
      clearTimeout(retryTimer);
    };

    ws.onmessage = e => {
      try {
        const d = JSON.parse(e.data);
        $('mainValue').textContent = d.mainVal  || '----';
        $('mainUnit').textContent  = d.mainUnit || '';
        $('subValue').textContent  = d.subVal   || '----';
        $('subUnit').textContent   = d.subUnit  || '';

        const flags = [];
        if (d.auto) flags.push('AUTO');
        if (d.max)  flags.push('MAX');
        if (d.min)  flags.push('MIN');
        if (d.avg)  flags.push('AVG');
        if (d.hold) flags.push('HOLD');
        if (d.rel)  flags.push('REL');
        $('flags').innerHTML = flags.map(f =>
          `<span class="on">${f}</span>`).join(' ');
      } catch(err) { console.error(err); }
    };

    ws.onclose = () => {
      $('status').textContent = 'Disconnected — reconnecting...';
      $('status').className = 'err';
      retryTimer = setTimeout(connect, 2000);
    };

    ws.onerror = () => ws.close();
  }

  connect();
</script>
</body>
</html>


)rawhtml";

// ─────────────────────────────────────────────────────────────────
//  Build JSON from a reading
// ─────────────────────────────────────────────────────────────────
String buildJSON(const BU86X_Reading &r) {
    // Extract just the numeric part for big display
    // mainDisplay is e.g. "-12.34 mV DC" — split at first space after digits
    String mainVal  = String(r.mainDisplay);
    String mainUnit = String(r.mainUnit);
    String subVal   = String(r.subDisplay);
    String subUnit  = String(r.subUnit);

    // Strip unit from display string to get just the number
    int sp = mainVal.indexOf(' ');
    if (sp > 0) { mainUnit = mainVal.substring(sp+1); mainVal = mainVal.substring(0, sp); }
    sp = subVal.indexOf(' ');
    if (sp > 0) { subUnit = subVal.substring(sp+1); subVal = subVal.substring(0, sp); }

    char buf[256];
    snprintf(buf, sizeof(buf),
        "{\"mainVal\":\"%s\",\"mainUnit\":\"%s\","
        "\"subVal\":\"%s\",\"subUnit\":\"%s\","
        "\"auto\":%s,\"max\":%s,\"min\":%s,"
        "\"avg\":%s,\"hold\":%s,\"rel\":%s,"
        "\"valid\":%s}",
        mainVal.c_str(), mainUnit.c_str(),
        subVal.c_str(),  subUnit.c_str(),
        r.flag_auto?"true":"false",
        r.flag_max ?"true":"false",
        r.flag_min ?"true":"false",
        r.flag_avg ?"true":"false",
        r.flag_hold?"true":"false",
        r.flag_rel ?"true":"false",
        r.valid    ?"true":"false"
    );
    return String(buf);
}

// ─────────────────────────────────────────────────────────────────
//  WebSocket event handler
// ─────────────────────────────────────────────────────────────────
void onWsEvent(AsyncWebSocket *server, AsyncWebSocketClient *client,
               AwsEventType type, void *arg, uint8_t *data, size_t len) {
    if (type == WS_EVT_CONNECT) {
        Serial.printf("[WS] Client %u connected\n", client->id());
        // Send latest reading immediately on connect
        portENTER_CRITICAL(&mux);
        BU86X_Reading snap = latest;
        portEXIT_CRITICAL(&mux);
        if (snap.valid) client->text(buildJSON(snap));
    }
    else if (type == WS_EVT_DISCONNECT) {
        Serial.printf("[WS] Client %u disconnected\n", client->id());
    }
}

// ─────────────────────────────────────────────────────────────────
//  setup()
// ─────────────────────────────────────────────────────────────────
void setup() {
    Serial.begin(115200);
    delay(1500);
    Serial.println("\nBU-86X WebSocket Gateway");

    // ── WiFi ─────────────────────────────────────────────────────
    Serial.printf("Connecting to %s ", WIFI_SSID);
    WiFi.begin(WIFI_SSID, WIFI_PASS);
    while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print('.'); }
    Serial.printf("\nIP: %s\n", WiFi.localIP().toString().c_str());
    Serial.printf("Open http://%s in your browser\n\n", WiFi.localIP().toString().c_str());

    // ── WebSocket ────────────────────────────────────────────────
    ws.onEvent(onWsEvent);
    server.addHandler(&ws);

    // ── HTTP routes ───────────────────────────────────────────────
    server.on("/", HTTP_GET, [](AsyncWebServerRequest *req) {
        req->send_P(200, "text/html", INDEX_HTML);
    });

    server.on("/reading", HTTP_GET, [](AsyncWebServerRequest *req) {
        portENTER_CRITICAL(&mux);
        BU86X_Reading snap = latest;
        portEXIT_CRITICAL(&mux);
        req->send(200, "application/json", buildJSON(snap));
    });

    server.begin();

    // ── BU-86X ───────────────────────────────────────────────────
    dmm.begin();
    Serial.println("Plug BU-86X into the OTG (bottom) USB port.");
}

// ─────────────────────────────────────────────────────────────────
//  loop()
// ─────────────────────────────────────────────────────────────────
void loop() {
    // Drive auto-trigger
    dmm.loop();

    // Check for new reading
    BU86X_Reading r;
    if (dmm.read(r)) {
        // Store latest
        portENTER_CRITICAL(&mux);
        latest    = r;
        newReading = true;
        portEXIT_CRITICAL(&mux);

        // Print to Serial
        dmm.printReading(r);

        // Broadcast to all WebSocket clients
        String json = buildJSON(r);
        ws.textAll(json);
    }

    // Periodic WebSocket cleanup
    static uint32_t wsClean = 0;
    if (millis() - wsClean > 5000) { wsClean = millis(); ws.cleanupClients(); }

    if (!dmm.isConnected()) {
        static uint32_t lastWarn = 0;
        if (millis() - lastWarn > 3000) {
            lastWarn = millis();
            Serial.println("Waiting for BU-86X...");
        }
    }
}
